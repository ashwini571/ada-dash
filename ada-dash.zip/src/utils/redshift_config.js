let user = 'awsuser'
let password = 'Gokaruna123'
let database = 'cpi'
let port = 5439
let host = 'redshift-cluster-1.c1t7hdxqfbsq.ap-south-1.redshift.amazonaws.com'

module.exports={
    user:user,
    password:password,
    database:database,
    port:port,
    host:host
}